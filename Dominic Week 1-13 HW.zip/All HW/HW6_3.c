#include <stdio.h>
#include <stdlib.h>

int main()

{

    float
    printf("Enter the operation of your choice.\n");
    printf("a. add          s. subtract\n");
    printf("m. multiply     d. divide\n");
    printf("q. quit");

}
