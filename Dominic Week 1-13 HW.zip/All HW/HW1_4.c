#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a;
    printf("Input a number: ");
    scanf("%d", &a);
    printf("The ASCII value of %d is %c", a, a);
    return 0;
}
