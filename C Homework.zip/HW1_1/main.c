
#include <stdlib.h>
#include <stdio.h>

int main() {

printf("Dominic Chua\n");
printf("Dominic\n");
printf("Chua\n");
printf("Dominic ");
printf("Chua\n");


return 0;
}
