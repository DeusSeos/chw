#include <stdio.h>
#include <stdlib.h>
#define gallonToliters 3.785;
#define milesTokilometers 1.609;

int main()
{

    int miles = 0;
    int gallons = 0;
    printf("Enter the number of miles traveled.\n");
    scanf("%i", &miles);
    printf("Enter the gallons of gas consumed.\n");
    scanf("%i", &gallons);
    float mpg = miles)/gallons
    print("%f", mpg)
    float liters = gallons*gallonsToLiters;
    printf("There are %f liters", liters);
    return 0;
}
